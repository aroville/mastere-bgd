# Codes TP3 : validation croisee

##################
# Question 1
##################

# Choix d'une grille de points x
nbpts = 1000
x = seq(-4,4,length.out=nbpts)

# Nombre d'observations
n = 100

# Densite 0
sigma = 1
X0 = rnorm(n,mean=0,sd=sigma)
f0 = dnorm(x,mean=0,sd=sigma)
x11()
plot(x,f0,type="l",lwd=2)
points(X0,rep(0,n),col="green",lwd=2)

# Densite 1
X1 = runif(n,min=-1,max=1)
f1 = dunif(x,min=-1,max=1)
x11()
plot(x,f1,type="l",lwd=2)
points(X1,rep(0,n),col="green",lwd=2)

# Densite 2
m = c(-1,1)
s = c(0.4,0.2)
p1 = 0.4
p2 = 0.6

c <- sample(c(1,2),size=n,prob=c(p1,p2),replace=TRUE)
X2 <-  rnorm(n,m[c],s[c])
f2 = p1*dnorm(x,m[1],s[1]) + p2*dnorm(x,m[2],s[2]) 
x11()
plot(x,f2,type="l",lwd=2)
points(X2,rep(0,n),col="green",lwd=2)

# Densite 3
p1 = 0.3
p2 = 0.7

c <- sample(c(1,2),size=n,prob=c(p1,p2),replace=TRUE)
X3 = rep(0,n)
for (i in 1:n) {
	if (c[i] == 1) {
		X3[i] = rnorm(1,mean=-1,sd=1)
		}
	if (c[i] == 2) {
		X3[i] = runif(1,min=0.5,max=1.5)
		}
	}
f3 = p1*dnorm(x,mean=-1,sd=1) + p2*dunif(x,min=0.5,max=1.5)
x11()
plot(x,f3,type="l",lwd=2)
points(X3,rep(0,n),col="green",lwd=2)

##############################
# Choix d'un echantillon
##############################

X = X0
f = f0

##############################
# Validation croiseee
##############################

# Choix d'une grille de valeurs pour h
M = 20
h = seq(0.5,0.55,length.out=M)
erreur = rep(0,M)
step = x[2]-x[1]

for (k in 1:M) {
	print(k)
	
	hatf = density(X,bw=h[k],kernel="gaussian",n=nbpts,from=-4, to= 4)$y
	aux = 0
	for (i in 1:n) {
		Xi = X[(1:n) != i]
		hatfi = density(Xi,bw=h[k],kernel="gaussian",n=1,from=X[i], to= X[i])$y
		aux = aux + hatfi/n
		}
	erreur[k] = step*sum(hatf^2)-2*aux
	}

x11()
plot(h,erreur)

# Minimisation de l'erreur
hopt = h[which.min(erreur)]

hatf = density(X,bw= hopt,kernel="gaussian",n=nbpts,from=-4, to= 4)$y

# Figure
x11()
plot(x,2*f,type="n",lwd=2,lty="dotdash")
lines(x,f,type="l",lwd=2,lty="dotdash")
lines(x,hatf, type = "l", col="red", lwd=2)
points(X,rep(0,n),col="green",lwd=2)

# Selection automatique de h par unbiased CV
hCV = bw.ucv(X,lower=0.1,upper=0.7)
hatf = density(X,bw=hCV,kernel="gaussian",n=nbpts,from=-4, to= 4)$y

# Figure
x11()
plot(x,2*f,type="n",lwd=2,lty="dotdash")
lines(x,f,type="l",lwd=2,lty="dotdash")
lines(x,hatf, type = "l", col="red", lwd=2)
points(X,rep(0,n),col="green",lwd=2)

##################
# Question 2
##################

# Donnees reelles
library(MASS)
data(iris3)
Iris = data.frame(rbind(iris3[,,1], iris3[,,2], iris3[,,3]))

# Iris est un tableau à 4 colonnes qui correspondent aux 4 mesures
n = 150
X1 = Iris[,1]
X2 = Iris[,2]
X3 = Iris[,3]
X4 = Iris[,4]

# Exemple d'estimation
X = X4
xmin = min(X)-1
xmax = max(X)+1
nbpts = 256
x = seq(xmin,xmax,length.out=nbpts)

# Utilisation du code precedent pour la validation croisee

# Choix d'une grille de valeurs pour h
M = 20
h = seq(0.01,0.2,length.out=M)
erreur = rep(0,M)

for (k in 1:M) {
	print(k)
	
	hatf = density(X,bw=h[k],kernel="gaussian",n=nbpts,from=-4, to= 4)$y
	aux = 0
	for (i in 1:n) {
		Xi = X[(1:n) != i]
		hatfi = density(Xi,bw=h[k],kernel="gaussian",n=1,from=X[i], to= X[i])$y
		aux = aux + hatfi/n
		}
	erreur[k] = step*sum(hatf^2)-2*aux
	}

x11()
plot(h,erreur)

# Minimisation de l'erreur
hopt = h[which.min(erreur)]

hatf = density(X,bw= hopt,kernel="gaussian",n=nbpts,from=xmin, to= xmax)$y

# Figure
x11()
plot(x,hatf, type = "l", col="red", lwd=2)
points(X,rep(0,n),col="green",lwd=2)


# Selection automatique de h par unbiased CV
hCV = bw.ucv(X,lower=0.001,upper=0.1)
hatf = density(X,bw=hCV,kernel="gaussian",n=nbpts,from=-4, to= 4)$y

# Figure
x11()
plot(x,hatf, type = "l", col="red", lwd=2)
points(X,rep(0,n),col="green",lwd=2)

##################
# Question 3
##################

# Ensemble de 4 fonctions tests
T = 1000
t = (1:T)/T

truef1 = 0.5 + (0.2*cos(4*pi*t)) + (0.1*cos(24*pi*t))
truef2 = 0.2 + 0.6*(t > 1/3 & t <= 0.75)
truef3 = 4*sin(4*pi*t) - sign(t - .3) - sign(.72 - t) + 5
truef4 = sqrt(t*(1-t))*sin((2*pi*1.05) /(t+.05)) + 0.5

# Choix des points du design : n valeurs regulierement espacees sur [0,1]
n <- 100
x <- seq(0,1,length.out=n)

# Choix du rapport signal sur bruit
rsnr = 5

# Data 1
f1 = 0.5 + (0.2*cos(4*pi*x)) + (0.1*cos(24*pi*x))
sigma1 <- sd(f1)/rsnr # Niveau de bruit
Y1 <- f1 + rnorm(n,mean=0,sd=sigma1)

# Data 2
f2 = 0.2 + 0.6*(x > 1/3 & x <= 0.75)
sigma2 <- sd(f2)/rsnr # Niveau de bruit
Y2 <- f2 + rnorm(n,mean=0,sd=sigma2)

# Data 3
f3 = 4*sin(4*pi*x) - sign(x - .3) - sign(.72 - x) + 5
sigma3 <- sd(f3)/rsnr # Niveau de bruit
Y3 <- f3 + rnorm(n,mean=0,sd=sigma3)

# Data 4
f4 = sqrt(x*(1-x))*sin((2*pi*1.05) /(x+.05)) + 0.5
sigma4 <- sd(f4)/rsnr # Niveau de bruit
Y4 <- f4 + rnorm(n,mean=0,sd=sigma4)


# Validation croisee pour la methode du noyau
library(KernSmooth)

# Choix d'un ensemble de donnees
Y = Y3
truef = truef3

# Choix d'une grille de valeurs pour h
M = 20
h = seq(0.05,0.09,length.out=M)
d = 5
erreur = rep(0,M)

for (k in 1:M) {
	print(k)

	for (i in 1:n) {
		xi = x[(1:n) != i]
		Yi = Y[(1:n) != i]
		fit = locpoly(xi,Yi,degree=d,bandwidth=h[k],gridsize=n,range.x=c(0,1))$y
		hatfi = fit[i]
		erreur[k] = erreur[k] + (Y[i]-hatfi)^2/n
		}
	}

x11()
plot(h,erreur)

# Minimisation de l'erreur
hopt = h[which.min(erreur)]

hatf = locpoly(x,Y,degree=d,bandwidth=hopt,gridsize=T,range.x=c(0,1))$y

# Visualisation
x11()
plot(t,truef, type = "l", col="red", lty="dotdash", lwd=2)
lines(t, hatf,type="l",col="blue", pch=19)


##################
# Question 4
##################

##########################
# Donnees sur les seismes
##########################

data(quakes)
x = quakes$long
Y = quakes$lat

#########################
# Donnnees sur le geyser
#########################

library(MASS)
data(geyser)

x = sort(geyser$duration)
ind = sort(geyser$duration,index.return=TRUE)
Y = geyser$waiting
Y = Y[ind$ix]

#########################
# Donnnees sur Animals
#########################
library(MASS)

x = log(Animals$body)
Y = Animals$brain

# Visualisation des donnees 
x11()
plot(x,Y,type="p",pch=19)

# Estimation par polynomes locaux
T = 1000
xmin = min(x)
xmax = max(x)
t = seq(xmin,xmax,length.out=T)
hatf = locpoly(x,Y,degree=0,bandwidth=1,gridsize=T,range.x=c(xmin,xmax))$y

# Visulisation de l'estimation
x11()
plot(x,Y,type="p",pch=19)
lines(t, hatf, type = "l", col="red",lwd=2)

# Validation croisee
n = length(x)
T = 1000
xmin = min(x)
xmax = max(x)
t = seq(xmin,xmax,length.out=T)

# Choix d'une grille de valeurs pour h
M = 20
h = seq(0.2,2,length.out=M)
erreur = rep(0,M)

# Attention il faut prendre en compte que le design n'est pas equi-reparti
# Il faut donc utiliser une bonne ponderation
W = x[2:n]-x[1:(n-1)]
W =c(W,W[n-1])
for (j in ((n-1):1)) {
	if (W[j] == 0) {
		W[j] = W[j+1]
		}
	}

for (k in 1:M) {
	print(k)

	for (i in 1:n) {
		xi = x[(1:n) != i]
		Yi = Y[(1:n) != i]
		fit = locpoly(xi,Yi,degree=0,bandwidth=h[k],gridsize=n,range.x=c(xmin,xmax))$y
		hatfi = fit[i]
		erreur[k] = erreur[k] + W[i]*(Y[i]-hatfi)^2
		}
	}

x11()
plot(h,erreur)

# Minimisation de l'erreur
hopt = h[which.min(erreur)]

hatf = locpoly(x,Y,degree=0,bandwidth=hopt,gridsize=T,range.x=c(xmin,xmax))$y

# Visulisation de l'estimation
x11()
plot(x,Y,type="p",pch=19)
lines(t, hatf, type = "l", col="red",lwd=2)

##################
# Question 5
##################

# Choix du degre en regression polynomiale

# Vraie fonction
theta <- c(1,-1,2,-0.8,0.6,-1)
T <- 100
t <- (1:T)/T
XT <- cbind(rep(1,T),t,t^2,t^3,t^4,t^5)
f <- XT%*%theta

# Visualisation de la fonction de regression
x11()
plot(t,f,type = "l", col="red", lwd=2)

# Choix des points du design : n valeurs regulierement espacees sur [0,1]
n <- 30
x <- (1:n)/n
X <- cbind(rep(1,n),x,x^2,x^3,x^4,x^5)

# Data 1
sigma <- 0.05 # Niveau de bruit
Y <- as.vector(X%*%theta + sigma*rnorm(n))

# Visualisation des donnees avec la fonction a reconstruire
x11()
plot(x,Y,type="p",pch=19)
lines(t,f, type = "l", col="red", lty="dotdash", lwd=2)

# Validation croisee pour 10 choix possibles de degre
erreur = rep(0,10)

for (i in 1:n) {
	print(i)
	
 	xi = x[(1:n) != i]
	Yi = Y[(1:n) != i]
	
	donneesi <- data.frame(y=Yi,x1=xi,x2=xi^2,x3=xi^3,x4=xi^4,x5=xi^5,x6=xi^6,x7=xi^7,x8=xi^8,x9=xi^9,x10=xi^10)
	testi <- data.frame(y=Y[i],x1=x[i],x2=x[i]^2,x3=x[i]^3,x4=x[i]^4,x5=x[i]^5,x6=x[i]^6,x7=x[i]^7,x8=x[i]^8,x9=x[i]^9,x10=x[i]^10)

	
	#d1
	m <- 1
	mod <- lm(y~x1,data=donneesi)
	erreur[m] = erreur[m] + (Y[i]-predict(mod,testi))^2/n

	#d2
	m <- 2
	mod <- lm(y~x1+x2,data=donneesi)
	erreur[m] = erreur[m] + (Y[i]-predict(mod,testi))^2/n

	#d3
	m <- 3
	mod <- lm(y~x1+x2+x3,data=donneesi)
	erreur[m] = erreur[m] + (Y[i]-predict(mod,testi))^2/n
	
	#d4
	m <- 4
	mod <- lm(y~x1+x2+x3+x4,data=donneesi)
	erreur[m] = erreur[m] + (Y[i]-predict(mod,testi))^2/n

	#d5
	m <- 5
	mod <- lm(y~x1+x2+x3+x4+x5,data=donneesi)
	erreur[m] = erreur[m] + (Y[i]-predict(mod,testi))^2/n

	#d6
	m <- 6
	mod <- lm(y~x1+x2+x3+x4+x5+x6,data=donneesi)
	erreur[m] = erreur[m] + (Y[i]-predict(mod,testi))^2/n

	#d7
	m <- 7
	mod <- lm(y~x1+x2+x3+x4+x5+x6+x7,data=donneesi)
	erreur[m] = erreur[m] + (Y[i]-predict(mod,testi))^2/n


	#d8
	m <- 8
	mod <- lm(y~x1+x2+x3+x4+x5+x6+x7+x8,data=donneesi)
	erreur[m] = erreur[m] + (Y[i]-predict(mod,testi))^2/n

	#d9
	m <- 9
	mod <- lm(y~x1+x2+x3+x4+x5+x6+x7+x8+x9,data=donneesi)
	erreur[m] = erreur[m] + (Y[i]-predict(mod,testi))^2/n

	#d10
	m <- 10
	mod <- lm(y~x1+x2+x3+x4+x5+x6+x7+x8+x9+x10,data=donneesi)
	erreur[m] = erreur[m] + (Y[i]-predict(mod,testi))^2/n
	
	}

# Estiamtion du degre
x11()
plot(1:10,erreur)

# Minimisation de l'erreur
mopt = which.min(erreur)

##################
# Question 6
##################

# Validation croisee leave p out
# Ne donne pas de tres bons resultats pour l'estimation de densite , a faire ventuellement ??

# Exemple pour l'estimation d'une densite

# Choix d'une grille de points x
nbpts = 1000
x = seq(-4,4,length.out=nbpts)

n = 100

# Densite 0
sigma = 1
X0 = rnorm(n,mean=0,sd=sigma)
f0 = dnorm(x,mean=0,sd=sigma)
x11()
plot(x,f0,type="l",lwd=2)
points(X0,rep(0,n),col="green",lwd=2)

X = X0
f = f0

##############################
# Validation croiseee
##############################

# Partition des individus en P sous-ensembles
P = 5
choix <- sample(1:P,size=n,prob=rep(1,P)/P,replace=TRUE)

# Choix d'une grille de valeurs pour h
M = 20
h = seq(0.1,2,length.out=M)
erreur = rep(0,M)

for (k in 1:M) {
	print(k)
	
	hatf = density(X,bw=h[k],kernel="gaussian",n=nbpts,from=-4, to= 4)$y
	aux = 0
	for (p in 1:P) {
		Xappr = X[choix != p]
		Xtest = X[choix == p]
		
		fit = density(Xappr,bw=h[k],kernel="gaussian",n=nbpts,from=-4, to= 4)$y
		# Approximation
		E = 0
		for (i in 1:length(Xtest)) {
			hatfi = fit[x > Xtest[i]]
			E = E + (hatfi[1]+hatfi[2])/2
			}
		aux = aux + E/length(Xtest)
		}
	erreur[k] = sum(hatf^2)-2*aux
	}

x11()
plot(h,erreur)

# Minimisation de l'erreur
hopt = h[which.min(erreur)]

hatf = density(X,bw= hopt,kernel="gaussian",n=nbpts,from=-4, to= 4)$y

# Figure
x11()
plot(x,2*f,type="n",lwd=2,lty="dotdash")
lines(x,f,type="l",lwd=2,lty="dotdash")
lines(x,hatf, type = "l", col="red", lwd=2)
points(X,rep(0,n),col="green",lwd=2)


