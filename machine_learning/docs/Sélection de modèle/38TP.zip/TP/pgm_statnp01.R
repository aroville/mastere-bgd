# programme bootstrap 
library(bootstrap)
n=30 #taille echantillon
r=0.5 # ceff de corr exact
sigma=1
B=999

x=rnorm(n,0,1)*sigma 
epsi=rnorm(n,0,1)*sigma
y=r*x+sqrt(1-r^2)*epsi

z=cbind(x,y)
corech=cor(x,y)

corel<-function(ind,z){ cor(z[ind,1],z[ind,2])}

vjack=jackknife(1:n,corel,z)

varrau=(vjack$jack.se)^2 # estimateur de la vraince de la correlation 

#intervalle de confiance asymptotique 
q2_5=corech-1.96*vjack$jack.se
q97_5=corech+1.96*vjack$jack.se 

resboot<-bootstrap(1:n,B,corel,z)
#valeur  bootstrap de la stat stock�e dans resboot$thetastar 
var(resboot$thetastar) #estimateur bootstrap de la variance

hist(resboot$thetastar)
plot(density(resboot$thetastar)) # densit� avec h calcul� automatiquement 

plot(density(resboot$thetastar,kernel="epanechnikov")) # noyau epachnechnikov
hopt=B^(-1/5)*(var(resboot$thetastar))^1/2*1.06
plot(density(resboot$thetastar,bw=hopt,kernel="epanechnikov")) # en specifieant la valeur optimale du cas gaussien




#Calcul de de Monte-Carlo de la vraie distribution du ceff corre et de la variance


B=10000
correl=matrix(0,B,3)
r=0.5
n=30

for (i in 1:B)
{
x=rnorm(n,0,1)
y=r*x+sqrt(1-r^2)*rnorm(30,0,1)
#x=exp(x)
#y=exp(y)
correl[i,1]=cor(x,y)
correl[i,2]=var(x)
correl[i,3]=var(y)}

nbpts = 1000
axe = seq(0,100,length.out=nbpts)

x11()
plot(axe,dchisq(axe,n-1))
lines(density(n*correl[,2]),type="l",col="red")


nbpts = 1000
axe = seq(-0.5,1.5,length.out=nbpts)
ectrau<-(var(correl[,1]))^0.5

x11()
plot(axe,dnorm(axe,r,ectrau))
lines(density(correl[,1],type="l",col="red")


# Construction de la methode t-percentile 

library(boot)
boott(1:n,corel,z)

# Bootstrap d'un modele lineaire

library(simpleboot)
data(airquality)
attach(airquality)

lmodel <- lm(Ozone ~ Wind)

lboot <- lm.boot(lmodel, R = 1000)
summary(lboot)





