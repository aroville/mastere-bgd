# Codes TP1 : regression polynomiale

##################
# Question 1
##################

# Vraie fonction
theta <- c(1,-1,2,-0.8,0.6,-1)
T <- 100
t <- (1:T)/T
XT <- cbind(rep(1,T),t,t^2,t^3,t^4,t^5)
f <- XT%*%theta

# Visualisation de la fonction de regression
x11()
plot(t,f,type = "l", col="red", lwd=2)


# Choix des points du design : n valeurs regulierement espacees sur [0,1]
n <- 30
x <- (1:n)/n
X <- cbind(rep(1,n),x,x^2,x^3,x^4,x^5)

# Data 1
sigma <- 0.05 # Niveau de bruit
Y <- as.vector(X%*%theta + sigma*rnorm(n))

# Visualisation des donnees
x11()
plot(x,Y,type="p",pch=19)

# Visualisation des donnees avec la fonction a reconstruire
x11()
plot(x,Y,type="p",pch=19)
lines(t,f, type = "l", col="red", lty="dotdash", lwd=2)

##################
# Question 2
##################

# Estimation par moindres carrés

# Degre 1
donnees <- data.frame(y=Y,x1=x)
mod1 <- lm(y~x1,data=donnees)
pred1 <- data.frame(x1=t)

# Figure
x11()
plot(x,Y,type="p",pch=19)
lines(t,f, type = "l", col="red", lty="dotdash", lwd=2)
lines(t,predict(mod1,pred1), lwd=2, col='black')

# Degre 4
donnees <- data.frame(y=Y,x1=x,x2=x^2,x3=x^3,x4=x^4)
mod4 <- lm(y~x1+x2+x3+x4,data=donnees)
pred4 <- data.frame(x1=t,x2=t^2,x3=t^3,x4=t^4)

# Figure
x11()
plot(x,Y,type="p",pch=19)
lines(t,f, type = "l", col="red", lty="dotdash", lwd=2)
lines(t,predict(mod4,pred4), lwd=2, col='black')


# Degre 15
donnees <- data.frame(y=Y,x1=x,x2=x^2,x3=x^3,x4=x^4,x5=x^5,x6=x^6,x7=x^7,x8=x^8,x9=x^9,x10=x^10,x11=x^11,x12=x^12,x13=x^13,x14=x^14,x15=x^15)
mod15 <- lm(y~x1+x2+x3+x4+x5+x6+x7+x8+x9+x10+x11+x12+x13+x14+x15,data=donnees)
pred15 <- data.frame(x1=t,x2=t^2,x3=t^3,x4=t^4,x5=t^5,x6=t^6,x7=t^7,x8=t^8,x9=t^9,x10=t^10,x11=t^11,x12=t^12,x13=t^13,x14=t^14,x15=t^15)

# Figure
x11()
plot(x,Y,type="p",pch=19)
lines(t,f, type = "l", col="red", lty="dotdash", lwd=2)
lines(t,predict(mod15,pred15), lwd=2, col='black')

# Degre 30
donnees <- data.frame(y=Y,x1=x,x2=x^2,x3=x^3,x4=x^4,x5=x^5,x6=x^6,x7=x^7,x8=x^8,x9=x^9,x10=x^10,x11=x^11,x12=x^12,x13=x^13,x14=x^14,x15=x^15,x16=x^16,x17=x^17,x18=x^18,x19=x^19,x20=x^20,x21=x^21,x22=x^22,x23=x^23,x24=x^24,x25=x^25,x26=x^26,x27=x^27,x28=x^28,x29=x^29,x30=x^30)
mod30 <- lm(y~x1+x2+x3+x4+x5+x6+x7+x8+x9+x10+x11+x12+x13+x14+x15+x16+x17+x18+x19+x20+x21+x22+x23+x24+x25+x26+x27+x28+x29+x30,data=donnees)
pred30 <- data.frame(x1=t,x2=t^2,x3=t^3,x4=t^4,x5=t^5,x6=t^6,x7=t^7,x8=t^8,x9=t^9,x10=t^10,x11=t^11,x12=t^12,x13=t^13,x14=t^14,x15=t^15,x16=t^16,x17=t^17,x18=t^18,x19=t^19,x20=t^20,x21=t^21,x22=t^22,x23=t^23,x24=t^24,x25=t^25,x26=t^26,x27=t^27,x28=t^28,x29=t^29,x30=t^30)

# Figure
x11()
plot(x,Y,type="p",pch=19)
lines(t,f, type = "l", col="red", lty="dotdash", lwd=2)
lines(t,predict(mod30,pred30), lwd=2, col='black')


##################
# Question 3
##################

# Jeu de donnees 2
# Code : idem que precedemment, il suffit de l'executer une deuxieme fois

# Data 2
Y <- as.vector(X%*%theta + sigma*rnorm(n))

x11()
plot(x,Y,type="p",pch=19)
lines(t,f, type = "l", col="red", lty="dotdash", lwd=2)

# Estimation par moindres carrés

# Degré 1
donnees <- data.frame(y=Y,x1=x)
mod1 <- lm(y~x1,data=donnees)
pred1 <- data.frame(x1=t)

# Figure
x11()
plot(x,Y,type="p",pch=19)
lines(t,f, type = "l", col="red", lty="dotdash", lwd=2)
lines(t,predict(mod1,pred1), lwd=2, col='black')

# Degré 4
donnees <- data.frame(y=Y,x1=x,x2=x^2,x3=x^3,x4=x^4)
mod4 <- lm(y~x1+x2+x3+x4,data=donnees)
pred4 <- data.frame(x1=t,x2=t^2,x3=t^3,x4=t^4)

# Figure
x11()
plot(x,Y,type="p",pch=19)
lines(t,f, type = "l", col="red", lty="dotdash", lwd=2)
lines(t,predict(mod4,pred4), lwd=2, col='black')
points(x,predict(mod4), lwd=2, col='green')

# Degré 15
donnees <- data.frame(y=Y,x1=x,x2=x^2,x3=x^3,x4=x^4,x5=x^5,x6=x^6,x7=x^7,x8=x^8,x9=x^9,x10=x^10,x11=x^11,x12=x^12,x13=x^13,x14=x^14,x15=x^15)
mod15 <- lm(y~x1+x2+x3+x4+x5+x6+x7+x8+x9+x10+x11+x12+x13+x14+x15,data=donnees)
pred15 <- data.frame(x1=t,x2=t^2,x3=t^3,x4=t^4,x5=t^5,x6=t^6,x7=t^7,x8=t^8,x9=t^9,x10=t^10,x11=t^11,x12=t^12,x13=t^13,x14=t^14,x15=t^15)


# Figure
x11()
plot(x,Y,type="p",pch=19)
lines(t,f, type = "l", col="red", lty="dotdash", lwd=2)
lines(t,predict(mod15,pred15), lwd=2, col='black')
points(x,predict(mod15), lwd=2, col='green')

##################
# Question 4
##################

# Erreur de prediction par rapport a la vraie fonction pour les degres : 1, 4 et 15
r1 = sum(predict(mod1,pred1)-f)^2/T
r4 = sum(predict(mod4,pred4)-f)^2/T
r15 = sum(predict(mod15,pred15)-f)^2/T

which.min(c(r1,r4,r15))

# Erreur de prediction par rapport aux donnees : 1, 4 et 15
e1 = sum(predict(mod1)-Y)^2/n
e4 = sum(predict(mod4)-Y)^2/n
e15 = sum(predict(mod15)-Y)^2/n

which.min(c(e1,e4,e15))

##################
# Question 5 et 6
##################

# Evaluation numerique du biais et de la variance pour des degres de 1 à 10
NbSimu= 100
M = 10
hatf = vector("list",M)
obs = matrix(0,NbSimu,n)

for (m in 1:M) {
	hatf[[m]] = matrix(0,NbSimu,n)
	}

for (nb in 1:NbSimu) {
	print(nb)		
	
	# Simulation de donnees		
	Y <- as.vector(X%*%theta + sigma*rnorm(n))
	donnees <- data.frame(y=Y,x1=x,x2=x^2,x3=x^3,x4=x^4,x5=x^5,x6=x^6,x7=x^7,x8=x^8,x9=x^9,x10=x^10)
	obs[nb,] = Y
	
	#d1
	m <- 1
	mod <- lm(y~x1,data=donnees)
	hatf[[m]][nb,] = predict(mod) 

	#d2
	m <- 2
	mod <- lm(y~x1+x2,data=donnees)
	hatf[[m]][nb,] = predict(mod) 

	#d3
	m <- 3
	mod <- lm(y~x1+x2+x3,data=donnees)
	hatf[[m]][nb,] = predict(mod) 
	
	#d4
	m <- 4
	mod <- lm(y~x1+x2+x3+x4,data=donnees)
	hatf[[m]][nb,] = predict(mod) 

	#d5
	m <- 5
	mod <- lm(y~x1+x2+x3+x4+x5,data=donnees)
	hatf[[m]][nb,] = predict(mod) 

	#d6
	m <- 6
	mod <- lm(y~x1+x2+x3+x4+x5+x6,data=donnees)
	hatf[[m]][nb,] = predict(mod) 

	#d7
	m <- 7
	mod <- lm(y~x1+x2+x3+x4+x5+x6+x7,data=donnees)
	hatf[[m]][nb,] = predict(mod) 


	#d8
	m <- 8
	mod <- lm(y~x1+x2+x3+x4+x5+x6+x7+x8,data=donnees)
	hatf[[m]][nb,] = predict(mod) 

	#d9
	m <- 9
	mod <- lm(y~x1+x2+x3+x4+x5+x6+x7+x8+x9,data=donnees)
	hatf[[m]][nb,] = predict(mod) 

	#d10
	m <- 10
	mod <- lm(y~x1+x2+x3+x4+x5+x6+x7+x8+x9+x10,data=donnees)
	hatf[[m]][nb,] = predict(mod) 
	
	}
	
# Biais
biais = rep(0,M)
truef = t(X%*%theta)

for (m in 1:M){
	biais[m] = mean( (apply(hatf[[m]],2,'mean') - truef)^2 )
	}

# Variance
variance = rep(0,M)
for (m in 1:M){
	moy = apply(hatf[[m]],2,'mean')
	variance[m] = mean( apply(hatf[[m]],2,'var') )
	}
	
##################
# Question 7
##################

# Risque Quadratique
risk = rep(0,M)
for (m in 1:M){
	risk[m] = biais[m] + variance[m]
	}
	
x11()
plot(1:M,risk,type = "l",col="red",lwd=2)

x11()
plot(1:M,variance, type = "l", col="green", lwd=2)

x11()
plot(1:M,biais, type = "l", lwd=2, col='green')

# Choix du degré par minimisation du risque quadratique
which.min(risk)

##################
# Question 8
##################

# Choix du degré par minimisation du risque empirique sur un un jeu de données
degre = rep(0,NbSimu)
erreur = rep(0,M)

for (nb in 1:NbSimu) {
	for (m in 1:M) {
		erreur[m] = mean( (obs[nb,]-hatf[[m]][nb,])^2 )
		}
	degre[nb] = which.min(erreur)
}

x11()
plot(1:NbSimu,degre, type = "l", lwd=2, col='red')



