%% ROW/USER BASED collaborative filtering 
%load the data 
p=load('u1_notime.base');%train data
testD=load('u1_notime.test');%test data

% file <uid, movie_id, rating>
users=max(p(:,1));
movies=max(p(:,2));
rank_matrix=zeros(users,movies); %users x movies matrix to store ratings 

% columns of user_id and movie_id to position in the matrix 
pos=p(:,1)+users*(p(:,2)-1); % vector with 
 rank_matrix(pos)=p(:,3); %usersx movies ratings
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 mean_ranks=zeros(users,1);
for i=1:1:users
    mean_ranks(i)=mean(rank_matrix(i,(find(rank_matrix(i,:)>0))));
end

% Plan for the lab
% 1. compute similarity among users (choose among alternatives: cosine, pearson corellation, corrcoefficient   
% 2. define k paramenter values (k nearest neighbours)
% 3. for each k
%       3.1 for each user u 
%           return k nearest neighbours k-N of u 
%       3.2 for each movie find the ratings of these users for the intersection
%       (movies( u ), movies(k-N))
%           3.2.1  compute the predicted ratings for user u (for the movies he has
%       not seen) - prediction either with mean value of k-NNs respective
%       ratings or mean value extended with u,k_n(i) similarity and 
%           3.2.2 find the error (predicted reating - actual rating from
%           the test data set)
%           sum the errors 
%       fill the error tble 
% 4. plot the error/k diagram. 
%       
%------------------------------------------------



